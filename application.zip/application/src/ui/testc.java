package ui;

import javax.swing.*;
import java.awt.*;

public class testc extends JFrame {

    public testc() {
        setTitle("Centered JPanel Example");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create the outer panel with a layout manager
        JPanel outerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        // Create the inner panel that you want to center
        JPanel innerPanel = new JPanel();
        innerPanel.setPreferredSize(new Dimension(200, 200)); // Set the preferred size as needed

        // Add components or customize the inner panel as needed
        JLabel label = new JLabel("This is a centered JPanel");
        innerPanel.add(label);

        // Add the inner panel to the outer panel
        outerPanel.add(innerPanel);

        // Add the outer panel to the frame
        add(outerPanel);

        // Set frame properties
        pack(); // Adjust the frame size based on its components
        setLocationRelativeTo(null); // Center the frame
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new testc());
    }
}
